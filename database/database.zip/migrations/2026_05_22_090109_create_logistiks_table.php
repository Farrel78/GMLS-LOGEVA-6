<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
    {
        Schema::create('logistiks', function (Blueprint $table) {

            $table->id();

            $table->foreignId('kategori_logistik_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('nama_item');

            $table->string('satuan');

            $table->text('deskripsi')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('logistiks');
    }
};
